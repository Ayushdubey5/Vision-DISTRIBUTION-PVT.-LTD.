"use client"

import { useState, useEffect } from "react"
import { Phone, Mail, Globe, MapPin, Users, Building, Award, Target, Handshake, Shield, TrendingUp } from "lucide-react"

export default function VisionDistribution() {
  const [scrollProgress, setScrollProgress] = useState(0)
  const [activeSection, setActiveSection] = useState("home")

  useEffect(() => {
    const handleScroll = () => {
      const totalScroll = document.documentElement.scrollTop
      const windowHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight
      const scroll = totalScroll / windowHeight
      setScrollProgress(scroll)

      // Update active section based on scroll position
      const sections = [
        "home",
        "about",
        "management",
        "verticals",
        "retail",
        "brand-licensing",
        "b2g",
        "govt-experience",
        "manufacturing",
        "achievements",
        "presence",
        "engagements",
        "contact",
      ]

      for (let i = sections.length - 1; i >= 0; i--) {
        const element = document.getElementById(sections[i])
        if (element && element.getBoundingClientRect().top <= 100) {
          setActiveSection(sections[i])
          break
        }
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
    }
  }

  const CountUp = ({ end, duration = 2000, suffix = "" }) => {
    const [count, setCount] = useState(0)
    const [isVisible, setIsVisible] = useState(false)

    useEffect(() => {
      const observer = new IntersectionObserver(
        ([entry]) => {
          if (entry.isIntersecting && !isVisible) {
            setIsVisible(true)
            let start = 0
            const increment = end / (duration / 16)
            const timer = setInterval(() => {
              start += increment
              if (start >= end) {
                setCount(end)
                clearInterval(timer)
              } else {
                setCount(Math.floor(start))
              }
            }, 16)
          }
        },
        { threshold: 0.1 },
      )

      const element = document.getElementById(`count-${end}`)
      if (element) observer.observe(element)

      return () => observer.disconnect()
    }, [end, duration, isVisible])

    return (
      <span id={`count-${end}`}>
        {count.toLocaleString()}
        {suffix}
      </span>
    )
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 bg-white shadow-lg z-50">
        <div className="h-1 bg-gradient-to-r from-green-500 to-blue-600">
          <div
            className="h-full bg-green-600 transition-all duration-300"
            style={{ width: `${scrollProgress * 100}%` }}
          />
        </div>
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-2">
              <div className="text-2xl font-bold">
                <span className="text-green-600">VIS</span>
                <span className="text-blue-600">ION</span>
              </div>
              <div className="text-sm text-gray-600">DISTRIBUTION PVT. LTD.</div>
            </div>
            <div className="hidden md:flex space-x-6">
              {[
                { id: "home", label: "Home" },
                { id: "about", label: "About" },
                { id: "management", label: "Management" },
                { id: "verticals", label: "Verticals" },
                { id: "retail", label: "Retail" },
                { id: "govt-experience", label: "Govt Experience" },
                { id: "achievements", label: "Achievements" },
                { id: "contact", label: "Contact" },
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className={`text-sm font-medium transition-colors ${
                    activeSection === item.id ? "text-green-600" : "text-gray-600 hover:text-green-600"
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section id="home" className="pt-20 min-h-screen bg-gradient-to-br from-green-50 to-blue-50 flex items-center">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="space-y-4">
                <h1 className="text-5xl md:text-6xl font-bold text-balance">
                  <span className="text-green-600">VISION</span>
                  <br />
                  <span className="text-blue-600">DISTRIBUTION</span>
                  <br />
                  <span className="text-gray-800 text-3xl">PVT. LTD.</span>
                </h1>
                <p className="text-xl text-gray-600 text-pretty">
                  Specialized Distribution House with Pan-India footprint since 1994
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-white p-4 rounded-lg shadow-md">
                  <div className="text-2xl font-bold text-green-600">
                    <CountUp end={1994} />
                  </div>
                  <div className="text-sm text-gray-600">Established</div>
                </div>
                <div className="bg-white p-4 rounded-lg shadow-md">
                  <div className="text-2xl font-bold text-blue-600">
                    ₹<CountUp end={4500} /> Cr
                  </div>
                  <div className="text-sm text-gray-600">Group Turnover FY 24-25</div>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <button
                  onClick={() => scrollToSection("verticals")}
                  className="bg-green-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors"
                >
                  Explore Verticals
                </button>
                <button
                  onClick={() => scrollToSection("contact")}
                  className="border-2 border-blue-600 text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-blue-600 hover:text-white transition-colors"
                >
                  Contact Us
                </button>
              </div>
            </div>

            <div className="relative">
              <img
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-08-28%20at%202.51.18%20AM-545YsynFAqd7duRK9qEitHo2yIZwuh.jpeg"
                alt="Vision Distribution Team"
                className="rounded-lg shadow-2xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* About Us */}
      <section id="about" className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">ABOUT US</h2>
            <div className="w-24 h-1 bg-gradient-to-r from-green-500 to-blue-500 mx-auto"></div>
          </div>

          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              {[
                "Head Quartered in New Delhi",
                "Commenced Distribution operations in India in the year 1994",
                "A Specialized Distribution House having in depth experience in Telecom trade",
                "First distribution house to import smart phones in India",
                "Having emphatic footprint in Pan India",
                "Group Turnover for FY 24~25-4500 Cr and growing",
              ].map((item, index) => (
                <div
                  key={index}
                  className="flex items-start space-x-3 opacity-0 animate-fade-in-up"
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
                  <p className="text-gray-700">{item}</p>
                </div>
              ))}
            </div>

            <div className="bg-gradient-to-br from-green-50 to-blue-50 p-8 rounded-lg">
              <div className="text-center space-y-4">
                <div className="text-6xl font-bold text-green-600">
                  <CountUp end={31} />
                </div>
                <div className="text-xl text-gray-700">Years of Excellence</div>
                <div className="text-gray-600">Leading the telecom distribution industry since 1994</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Management */}
      <section id="management" className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">MANAGEMENT</h2>
            <div className="w-24 h-1 bg-gradient-to-r from-green-500 to-blue-500 mx-auto"></div>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                name: "RAJIV BABBAR",
                position: "MANAGING DIRECTOR",
                description:
                  "A law graduate from Delhi University, a professional turned entrepreneur, with over 27 years of experience in consumer electronics, Digital Cameras & Telecom Sector. In 2004 he ventured into the mobile distribution business by launching first PDA smart phone (IMATE) in India. He is also a founder member of Indian Cellular and Electronic Association.",
              },
              {
                name: "GIRISH NEGI",
                position: "CEO",
                description:
                  "A dynamic strategic thinker, motivator, entrepreneur having more than 25 years of rich experience in telecommunication industry, imaging and consumer electronics. He has been instrumental in expanding SAMSUNG, BLACKBERRY, SONY, HTC in Delhi NCR and HUAWEI business PAN India.",
              },
              {
                name: "PRAGUN BABBAR",
                position: "DIRECTOR",
                description:
                  "A tech enthusiast having interest in latest gadgets especially focused on developing new businesses and implementing technology driven business solutions. A Law graduate and aspiring entrepreneur.",
              },
            ].map((member, index) => (
              <div
                key={index}
                className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow"
              >
                <div className="h-64 bg-gradient-to-br from-green-100 to-blue-100 flex items-center justify-center">
                  <div className="w-32 h-32 bg-gray-300 rounded-full flex items-center justify-center">
                    <Users className="w-16 h-16 text-gray-500" />
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold text-gray-800 mb-1">{member.name}</h3>
                  <p className="text-green-600 font-semibold mb-4">{member.position}</p>
                  <p className="text-gray-600 text-sm leading-relaxed">{member.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Business Verticals */}
      <section id="verticals" className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">BUSINESS VERTICALS</h2>
            <div className="w-24 h-1 bg-gradient-to-r from-green-500 to-blue-500 mx-auto"></div>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                title: "Distribution Business",
                icon: <Building className="w-12 h-12" />,
                description: "Authorised partner for iPads, iPhone, and accessories",
                color: "blue",
              },
              {
                title: "B2G / B2B Business",
                icon: <Target className="w-12 h-12" />,
                description: "Executed orders worth 2900+ cr. in last three years",
                color: "green",
              },
              {
                title: "Retail Chain",
                icon: <Building className="w-12 h-12" />,
                description: "A mobility retail chain with dominant presence in Delhi NCR",
                color: "purple",
              },
              {
                title: "Brand Licensing",
                icon: <Award className="w-12 h-12" />,
                description: "Licensee of Swiss Military brand for Mobile Accessories",
                color: "red",
              },
              {
                title: "Manufacturing",
                icon: <Building className="w-12 h-12" />,
                description: "Production capacity of more than 70000 units per month",
                color: "orange",
              },
              {
                title: "Sports & Entertainment",
                icon: <Target className="w-12 h-12" />,
                description: "Acquired PURANI DELHI-6 Team in Delhi Premier T20 Cricket League",
                color: "indigo",
              },
            ].map((vertical, index) => (
              <div
                key={index}
                className="bg-white border-2 border-gray-100 rounded-lg p-6 hover:border-green-300 hover:shadow-lg transition-all cursor-pointer group"
              >
                <div className={`text-${vertical.color}-600 mb-4 group-hover:scale-110 transition-transform`}>
                  {vertical.icon}
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-3">{vertical.title}</h3>
                <p className="text-gray-600 text-sm">{vertical.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Retail Chain */}
      <section id="retail" className="py-20 bg-gradient-to-br from-green-50 to-blue-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">RETAIL CHAIN</h2>
            <div className="w-24 h-1 bg-gradient-to-r from-green-500 to-blue-500 mx-auto mb-4"></div>
            <p className="text-xl text-gray-600">
              Mobiliti World - Your Go-To Destination for Smartphones & Accessories
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-2xl font-bold text-green-600 mb-2">Current Footprint</h3>
                <p className="text-gray-700">
                  Operating{" "}
                  <span className="font-bold text-blue-600">
                    <CountUp end={27} />
                  </span>{" "}
                  premium retail stores across key urban and suburban markets in Delhi NCR
                </p>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-2xl font-bold text-blue-600 mb-2">Expansion Vision</h3>
                <p className="text-gray-700">
                  Ambitiously scaling to{" "}
                  <span className="font-bold text-green-600">
                    <CountUp end={100} />+
                  </span>{" "}
                  stores within the next 12 months
                </p>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-2xl font-bold text-purple-600 mb-2">Product Range</h3>
                <p className="text-gray-700">
                  Offering the latest smartphones, accessories, gadgets, and tech essentials — all under one roof
                </p>
              </div>
            </div>

            <div className="text-center">
              <div className="bg-white p-8 rounded-lg shadow-lg">
                <div className="text-6xl font-bold text-red-600 mb-4">
                  <div className="flex items-center justify-center space-x-2">
                    <span className="text-4xl">🏪</span>
                    <span>MOBILITI</span>
                  </div>
                  <div className="text-3xl text-blue-600">WORLD</div>
                </div>
                <p className="text-gray-600 mt-4">Mobility lifestyle destination for the modern Indian consumer</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Brand Licensing */}
      <section id="brand-licensing" className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">BRAND LICENSING</h2>
            <div className="w-24 h-1 bg-gradient-to-r from-green-500 to-blue-500 mx-auto"></div>
          </div>

          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <div className="flex items-center space-x-4 mb-6">
                <div className="w-16 h-16 bg-red-600 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-2xl">+</span>
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-gray-800">SWISS MILITARY</h3>
                  <p className="text-gray-600">Wearables and Hearables | India Market</p>
                </div>
              </div>

              <p className="text-gray-700 leading-relaxed">
                Vision Distribution is the proud licensee of the globally respected SWISS MILITARY brand for the
                wearables and hearables category in the Indian market.
              </p>

              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span className="text-gray-700">
                    Available in{" "}
                    <span className="font-bold text-green-600">
                      <CountUp end={5000} />+
                    </span>{" "}
                    retail outlets and growing
                  </span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  <span className="text-gray-700">Trusted by leading LFRs (Large Format Retailers)</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                  <span className="text-gray-700">
                    Widely distributed through key retail channel partners nationwide
                  </span>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-br from-red-50 to-gray-50 p-8 rounded-lg text-center">
              <div className="text-6xl font-bold text-red-600 mb-4">
                SWISS
                <br />
                MILITARY
              </div>
              <p className="text-gray-600">World-class products with Swiss precision delivered to Indian consumers</p>
            </div>
          </div>
        </div>
      </section>

      {/* B2G/B2B Business */}
      <section id="b2g" className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">B2G / B2B BUSINESS</h2>
            <div className="w-24 h-1 bg-gradient-to-r from-green-500 to-blue-500 mx-auto"></div>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-lg shadow-lg text-center hover:shadow-xl transition-shadow">
              <div className="text-4xl font-bold text-green-600 mb-2">
                ₹<CountUp end={2900} />+ Cr
              </div>
              <div className="text-gray-600">Orders Executed</div>
              <div className="text-sm text-gray-500 mt-2">in last three years</div>
            </div>

            <div className="bg-white p-8 rounded-lg shadow-lg text-center hover:shadow-xl transition-shadow">
              <div className="text-4xl font-bold text-blue-600 mb-2">
                <CountUp end={6.25} /> Lakh
              </div>
              <div className="text-gray-600">Tablets Delivered</div>
              <div className="text-sm text-gray-500 mt-2">Biggest order pan India</div>
            </div>

            <div className="bg-white p-8 rounded-lg shadow-lg text-center hover:shadow-xl transition-shadow">
              <div className="text-4xl font-bold text-purple-600 mb-2">#1</div>
              <div className="text-gray-600">Samsung Partner</div>
              <div className="text-sm text-gray-500 mt-2">Biggest partner by Samsung India in 2023</div>
            </div>
          </div>
        </div>
      </section>

      {/* Government Experience */}
      <section id="govt-experience" className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">OUR GOVT. EXPERIENCE</h2>
            <div className="w-24 h-1 bg-gradient-to-r from-green-500 to-blue-500 mx-auto"></div>
          </div>

          <div className="grid md:grid-cols-2 gap-12">
            <div className="space-y-6">
              <div className="bg-gradient-to-r from-green-500 to-blue-500 text-white p-6 rounded-lg">
                <h3 className="text-2xl font-bold mb-4">Order Execution</h3>
                <p className="text-lg">
                  Order executed more than{" "}
                  <span className="font-bold">
                    <CountUp end={23} /> lacs unit
                  </span>{" "}
                  of SMARTPHONE, TABLETS, and SMART CLASS SOLUTIONS with order value of approx.
                  <span className="font-bold">
                    {" "}
                    ₹<CountUp end={2900} /> cr
                  </span>
                  .
                </p>
              </div>

              <div className="bg-gray-50 p-6 rounded-lg">
                <h4 className="text-xl font-bold text-gray-800 mb-4">States Covered</h4>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  {[
                    "J&K",
                    "Uttrakhand",
                    "Himachal",
                    "Haryana",
                    "Delhi",
                    "Uttar Pradesh",
                    "Maharashtra",
                    "Telangana",
                    "Andhra Pradesh",
                    "Manipur",
                  ].map((state, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span className="text-gray-700">{state}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="bg-gray-50 p-6 rounded-lg">
              <h4 className="text-xl font-bold text-gray-800 mb-4">Departments/Organizations</h4>
              <div className="space-y-3">
                {[
                  "Women & Child Development",
                  "National Health Mission",
                  "Education",
                  "Animal Husbandary",
                  "IT",
                  "BHEL",
                  "ISRO",
                ].map((dept, index) => (
                  <div key={index} className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                      <Building className="w-4 h-4 text-blue-600" />
                    </div>
                    <span className="text-gray-700">{dept}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Manufacturing */}
      <section id="manufacturing" className="py-20 bg-gradient-to-br from-orange-50 to-yellow-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">MANUFACTURING UNIT</h2>
            <div className="w-24 h-1 bg-gradient-to-r from-green-500 to-blue-500 mx-auto mb-4"></div>
            <p className="text-xl text-gray-600">A Trusted Backbone for Leading Brands</p>
          </div>

          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <p className="text-gray-700 leading-relaxed">
                Located at the heart of innovation and efficiency, our manufacturing facility serves as the engine
                behind some of the most trusted names in the market. With a focus on quality, scale, and reliability —
                we bring products to life that meet global standards.
              </p>

              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-2xl font-bold text-orange-600 mb-2">Production Capacity</h3>
                <div className="text-4xl font-bold text-gray-800">
                  <CountUp end={70000} />+ units/month
                </div>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-2xl font-bold text-blue-600 mb-2">Business Philosophy</h3>
                <p className="text-gray-700">
                  Manufacturing unit built on the thought of reverse integration in the business
                </p>
              </div>
            </div>

            <div className="text-center">
              <div className="text-6xl font-bold text-orange-600 mb-4">BUZZ</div>
              <p className="text-gray-600 mb-6">Our OEM Partners</p>
              <div className="grid grid-cols-2 gap-4">
                {["Swiss Military", "Boat", "PlanX", "Candytech", "Intex"].map((partner, index) => (
                  <div key={index} className="bg-white p-4 rounded-lg shadow-md text-center">
                    <span className="text-gray-700 font-semibold">{partner}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Achievements */}
      <section id="achievements" className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">ACHIEVEMENTS</h2>
            <div className="w-24 h-1 bg-gradient-to-r from-green-500 to-blue-500 mx-auto"></div>
          </div>

          <div className="space-y-6">
            {[
              "We always think long term and our journey with each brand has been an average of 5 years.",
              "We are among the top 3 Apple distributors across India.",
              "Successfully completed and delivered 3 Lakhs tablet and 4.5 Lakhs mobile phones in Uttar Pradesh at 54 different locations. For which UP CM himself praised our organization for the timely execution.",
              "Set up pan India distribution for honor mobiles.",
              "Successfully completed and delivered 6.19 Lakhs Tablets in Haryana in 22 districts.",
              "Set up distribution for Infocus Mobile phones in North & East India.",
            ].map((achievement, index) => (
              <div
                key={index}
                className="flex items-start space-x-4 bg-gray-50 p-6 rounded-lg hover:bg-green-50 transition-colors"
              >
                <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <Award className="w-4 h-4 text-white" />
                </div>
                <p className="text-gray-700 leading-relaxed">{achievement}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pan India Presence */}
      <section id="presence" className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">PAN INDIA PRESENCE</h2>
            <div className="w-24 h-1 bg-gradient-to-r from-green-500 to-blue-500 mx-auto"></div>
          </div>

          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="grid grid-cols-2 gap-6">
                <div className="bg-green-600 text-white p-6 rounded-lg text-center">
                  <div className="text-3xl font-bold mb-2">
                    <CountUp end={9} />
                  </div>
                  <div className="text-sm">Office & Warehouses</div>
                </div>

                <div className="bg-blue-600 text-white p-6 rounded-lg text-center">
                  <div className="text-3xl font-bold mb-2">
                    <CountUp end={300} />+
                  </div>
                  <div className="text-sm">Man Power</div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <div className="w-4 h-4 bg-green-500 rounded-full"></div>
                  <span className="text-gray-700 font-semibold">Head Office</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-4 h-4 bg-blue-500 rounded-full"></div>
                  <span className="text-gray-700 font-semibold">Branch Location</span>
                </div>
              </div>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-lg">
              <img src="/india-map-showing-pan-india-presence-with-office-l.png" alt="Pan India Presence Map" className="w-full h-auto rounded-lg" />
            </div>
          </div>
        </div>
      </section>

      {/* Competitive Advantages */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">OUR COMPETITIVE ADVANTAGES</h2>
            <div className="w-24 h-1 bg-gradient-to-r from-green-500 to-blue-500 mx-auto"></div>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-red-500 text-white p-6 rounded-lg">
              <div className="flex items-center space-x-3 mb-4">
                <Handshake className="w-8 h-8" />
                <h3 className="text-xl font-bold">RELATIONSHIP COMES FIRST</h3>
              </div>
              <ul className="space-y-2 text-sm">
                <li>• Regular contact with Channel Partners</li>
                <li>• Management and team having positive attitude towards the brands we represent</li>
                <li>• Taking ownership of the brand</li>
              </ul>
            </div>

            <div className="bg-blue-500 text-white p-6 rounded-lg">
              <div className="flex items-center space-x-3 mb-4">
                <Shield className="w-8 h-8" />
                <h3 className="text-xl font-bold">HONESTY AND INTEGRITY</h3>
              </div>
              <ul className="space-y-2 text-sm">
                <li>• Impeccable market reputation</li>
                <li>• No Dispute with any Channel Partners over 25 years</li>
                <li>• Personal stake in growth of each Partner</li>
              </ul>
            </div>

            <div className="bg-green-500 text-white p-6 rounded-lg">
              <div className="flex items-center space-x-3 mb-4">
                <TrendingUp className="w-8 h-8" />
                <h3 className="text-xl font-bold">CREATE WIN-WIN SITUATION</h3>
              </div>
              <ul className="space-y-2 text-sm">
                <li>• Treating channel partners as close associates</li>
                <li>• Having a service attitude rather than "Big Brother" attitude</li>
                <li>• Team of best players who know where to play and how to win</li>
              </ul>
            </div>
          </div>

          <div className="text-center mt-12">
            <p className="text-xl text-gray-600 italic">
              Our core capabilities uniquely meet <span className="font-bold text-green-600">PARTNER'S</span> need
            </p>
          </div>
        </div>
      </section>

      {/* Dealer Engagements & CSR */}
      <section id="engagements" className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12">
            <div>
              <h2 className="text-3xl font-bold text-gray-800 mb-8">DEALER ENGAGEMENTS</h2>

              <div className="space-y-8">
                <div className="bg-white p-6 rounded-lg shadow-md">
                  <h3 className="text-xl font-bold text-blue-600 mb-4">Birthdays & Festival Wishes</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <img
                      src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-08-28%20at%202.51.18%20AM-545YsynFAqd7duRK9qEitHo2yIZwuh.jpeg"
                      alt="Birthday celebrations"
                      className="rounded-lg"
                    />
                    <img
                      src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-08-28%20at%202.51.21%20AM-NpHGJEstJHFZvMIisoDEp9XaPkHEws.jpeg"
                      alt="Festival celebrations"
                      className="rounded-lg"
                    />
                  </div>
                </div>

                <div className="bg-white p-6 rounded-lg shadow-md">
                  <h3 className="text-xl font-bold text-green-600 mb-4">Cricket Match</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <img
                      src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-08-28%20at%202.51.20%20AM-42PtND58tEtR8ChYxgsreTBDWUCzRM.jpeg"
                      alt="Cricket tournament"
                      className="rounded-lg"
                    />
                    <img
                      src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-08-28%20at%202.51.19%20AM%20%281%29-dVtZOCKWoCvG1ogxwrgMaZHGsxEzSy.jpeg"
                      alt="Cricket match"
                      className="rounded-lg"
                    />
                  </div>
                </div>
              </div>
            </div>

            <div>
              <h2 className="text-3xl font-bold text-gray-800 mb-8">CSR INITIATIVES</h2>

              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-bold text-green-600 mb-4">Tree Plantation</h3>
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <img
                    src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-08-28%20at%202.51.19%20AM-DUgsgymganIVp0J4ICEXU1MPOPO8hF.jpeg"
                    alt="Tree plantation drive"
                    className="rounded-lg"
                  />
                  <img src="/tree-plantation-csr-activity.png" alt="Environmental initiative" className="rounded-lg" />
                </div>
                <p className="text-gray-600">
                  Our commitment to environmental sustainability through regular tree plantation drives and green
                  initiatives across our operational areas.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact */}
      <section id="contact" className="py-20 bg-gradient-to-br from-green-600 to-blue-600 text-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">CONTACT US</h2>
            <div className="w-24 h-1 bg-white mx-auto"></div>
          </div>

          <div className="grid md:grid-cols-2 gap-12">
            <div className="space-y-6">
              <div className="flex items-start space-x-4">
                <MapPin className="w-6 h-6 mt-1 flex-shrink-0" />
                <div>
                  <h3 className="font-bold mb-2">Address</h3>
                  <p>H-47, Bali Nagar, New Delhi-110015 (INDIA)</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <Phone className="w-6 h-6 mt-1 flex-shrink-0" />
                <div>
                  <h3 className="font-bold mb-2">Phone</h3>
                  <p>011-46380029</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <Mail className="w-6 h-6 mt-1 flex-shrink-0" />
                <div>
                  <h3 className="font-bold mb-2">Email</h3>
                  <p>support@vdpl.in</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <Globe className="w-6 h-6 mt-1 flex-shrink-0" />
                <div>
                  <h3 className="font-bold mb-2">Website</h3>
                  <p>www.visionworld.in</p>
                </div>
              </div>
            </div>

            <div className="bg-white bg-opacity-10 p-6 rounded-lg">
              <h3 className="text-2xl font-bold mb-6">Get In Touch</h3>
              <form className="space-y-4">
                <input
                  type="text"
                  placeholder="Your Name"
                  className="w-full p-3 rounded-lg bg-white bg-opacity-20 placeholder-white border border-white border-opacity-30 text-white"
                />
                <input
                  type="email"
                  placeholder="Your Email"
                  className="w-full p-3 rounded-lg bg-white bg-opacity-20 placeholder-white border border-white border-opacity-30 text-white"
                />
                <input
                  type="tel"
                  placeholder="Your Phone"
                  className="w-full p-3 rounded-lg bg-white bg-opacity-20 placeholder-white border border-white border-opacity-30 text-white"
                />
                <textarea
                  placeholder="Your Message"
                  rows="4"
                  className="w-full p-3 rounded-lg bg-white bg-opacity-20 placeholder-white border border-white border-opacity-30 text-white resize-none"
                ></textarea>
                <button
                  type="submit"
                  className="w-full bg-white text-green-600 font-bold py-3 rounded-lg hover:bg-gray-100 transition-colors"
                >
                  Send Message
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="text-center">
            <div className="text-6xl font-bold mb-4">
              <span className="text-green-400">VIS</span>
              <span className="text-blue-400">ION</span>
            </div>
            <div className="text-xl text-gray-300 mb-8">DISTRIBUTION PVT. LTD.</div>

            <div className="text-4xl font-bold text-gray-300 mb-8">Thank you</div>

            <div className="flex justify-center space-x-8 text-sm text-gray-400">
              <button onClick={() => scrollToSection("home")}>Home</button>
              <button onClick={() => scrollToSection("about")}>About</button>
              <button onClick={() => scrollToSection("verticals")}>Verticals</button>
              <button onClick={() => scrollToSection("contact")}>Contact</button>
            </div>

            <div className="mt-8 pt-8 border-t border-gray-700 text-sm text-gray-400">
              © 2024 Vision Distribution Pvt. Ltd. All rights reserved.
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
