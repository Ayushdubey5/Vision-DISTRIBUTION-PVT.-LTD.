import React, { useState, useEffect } from 'react';
import { Heart, Star, MessageCircle, Phone, Mail, User, Calendar, MapPin, Menu, X, ArrowLeft, Send, Lock, Eye, EyeOff, CheckCircle, Clock, CreditCard } from 'lucide-react';

// Real packages data with Rs 1000 discount applied
const packages = [
  {
    id: 1,
    name: "To the Moon",
    description: "Fall in love under the stars with this celestial-themed setup that feels straight out of a fairytale. Featuring a glowing moon backdrop, a twinkling light path, heart balloons, and a garden of soft white blooms — this setup is perfect for a magical date night, dreamy proposal, or anniversary celebration.",
    price: 49000,
    originalPrice: 50000,
    image: "/To the moon.jpeg",
    category: "proposal",
    features: ["Glowing Moon Backdrop", "Twinkling Light Path", "Heart Balloons", "Soft White Blooms", "Celestial Decorations", "Professional Setup"]
  },
  {
    id: 2,
    name: "Boho Bliss Date Setup",
    description: "Looking for something intimate, cozy, and magical? This warm boho-inspired setup under the stars features soft cushions, dreamy fairy lights, rustic lanterns, and a romantic low table — perfect for a heart-to-heart evening with your special someone.",
    price: 19000,
    originalPrice: 20000,
    image: "/Boho Bliss Date Setup.jpeg",
    category: "romantic",
    features: ["Soft Cushions", "Dreamy Fairy Lights", "Rustic Lanterns", "Romantic Low Table", "Boho Decorations", "Cozy Atmosphere"]
  },
  {
    id: 3,
    name: "La Paris",
    description: "Can't take them to Paris? Let us bring Paris to you! This romantic setup features a glowing Eiffel Tower, rose petals, candle-lit pathways, fairy lights, and heart balloons — creating the perfect 'City of Love' vibe right here.",
    price: 18299,
    originalPrice: 19299,
    image: "/La Paris.jpeg",
    category: "romantic",
    features: ["Glowing Eiffel Tower", "Rose Petals", "Candle-lit Pathways", "Fairy Lights", "Heart Balloons", "Parisian Theme"]
  },
  {
    id: 4,
    name: "Cabana in the Garden",
    description: "When love deserves a moment as grand as the feeling itself... this is where the magic begins. Set under the stars, this luxurious setup features a rose-petal aisle, glowing candles, romantic heart balloons, and a glowing 'MARRY ME' marquee — all leading to a candlelit cabana made just for two.",
    price: 17500,
    originalPrice: 18500,
    image: "/Cabana in the garden.jpeg",
    category: "proposal",
    features: ["Rose-petal Aisle", "Glowing Candles", "MARRY ME Marquee", "Candlelit Cabana", "Heart Balloons", "Luxury Setup"]
  },
  {
    id: 5,
    name: "Date under the Tree",
    description: "Step into a fairytale evening designed just for two. Under the grand palm tree dressed in golden lights, cascading florals, and balloons, this enchanting date setup creates the perfect backdrop for heartfelt conversations, laughter, and unforgettable memories.",
    price: 11500,
    originalPrice: 12500,
    image: "/Date under the Tree.jpeg",
    category: "romantic",
    features: ["Golden Tree Lights", "Cascading Florals", "Rose-petal Aisle", "Glowing Lanterns", "White Umbrellas", "Cozy Seating"]
  }
];

const categories = [
  { id: 'all', name: 'All Packages', icon: <Heart size={20} /> },
  { id: 'romantic', name: 'Romantic Dates', icon: <Heart size={20} /> },
  { id: 'proposal', name: 'Proposals', icon: <Star size={20} /> },
  { id: 'birthday', name: 'Birthdays', icon: <Calendar size={20} /> },
  { id: 'anniversary', name: 'Anniversaries', icon: <Heart size={20} /> }
];

function App() {
  const [currentPage, setCurrentPage] = useState('home');
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [selectedPackage, setSelectedPackage] = useState(null);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [user, setUser] = useState(null);
  const [showLoginForm, setShowLoginForm] = useState(false);
  const [isSignup, setIsSignup] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [bookingForm, setBookingForm] = useState({
    packageId: null,
    date: '',
    time: '',
    venue: '',
    specialRequests: '',
    guestCount: 2
  });
  const [contactForm, setContactForm] = useState({
    name: '',
    email: '',
    phone: '',
    message: ''
  });
  const [loginForm, setLoginForm] = useState({
    email: '',
    password: '',
    name: '',
    phone: ''
  });

  // Mock user bookings
  const [userBookings, setUserBookings] = useState([
    {
      id: 1,
      packageName: "To the Moon",
      date: "2024-02-14",
      status: "confirmed",
      amount: 49000,
      venue: "Rooftop Garden"
    }
  ]);

  // Smooth scroll animation
  useEffect(() => {
    const observerOptions = {
      threshold: 0.1,
      rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.style.opacity = '1';
          entry.target.style.transform = 'translateY(0)';
        }
      });
    }, observerOptions);

    const animateElements = document.querySelectorAll('.animate-on-scroll');
    animateElements.forEach((el) => {
      el.style.opacity = '0';
      el.style.transform = 'translateY(30px)';
      el.style.transition = 'opacity 0.8s ease-out, transform 0.8s ease-out';
      observer.observe(el);
    });

    return () => observer.disconnect();
  }, [currentPage]);

  const handleLogin = (e) => {
    e.preventDefault();
    // Mock login - in real app, this would call your backend API
    const mockUser = {
      id: 1,
      name: isSignup ? loginForm.name : 'John Doe',
      email: loginForm.email,
      phone: isSignup ? loginForm.phone : '+91 9876543210'
    };
    setUser(mockUser);
    setShowLoginForm(false);
    setLoginForm({ email: '', password: '', name: '', phone: '' });
  };

  const handleBooking = (e) => {
    e.preventDefault();
    if (!user) {
      setShowLoginForm(true);
      return;
    }
    
    // Mock booking submission
    const newBooking = {
      id: Date.now(),
      packageName: selectedPackage.name,
      date: bookingForm.date,
      status: "pending",
      amount: selectedPackage.price,
      venue: bookingForm.venue
    };
    setUserBookings([...userBookings, newBooking]);
    alert('Booking submitted successfully! We will contact you soon.');
    setBookingForm({
      packageId: null,
      date: '',
      time: '',
      venue: '',
      specialRequests: '',
      guestCount: 2
    });
  };

  const handleContactSubmit = (e) => {
    e.preventDefault();
    // Mock contact form submission
    alert('Message sent successfully! We will get back to you soon.');
    setContactForm({ name: '', email: '', phone: '', message: '' });
  };

  const filteredPackages = selectedCategory === 'all' 
    ? packages 
    : packages.filter(pkg => pkg.category === selectedCategory);

  const Navigation = () => (
    <nav className="fixed top-0 left-0 right-0 bg-white/95 backdrop-blur-md z-50 shadow-sm border-b border-rose-100">
      <div className="container mx-auto px-4 py-3">
        <div className="flex justify-between items-center">
          <div 
            className="flex items-center space-x-2 cursor-pointer group"
            onClick={() => setCurrentPage('home')}
          >
            <Heart className="text-rose-500 fill-current group-hover:scale-110 transition-transform" size={28} />
            <span className="text-2xl font-bold bg-gradient-to-r from-rose-500 via-purple-600 to-pink-500 bg-clip-text text-transparent">
              WildlyTogether
            </span>
          </div>
          
          <div className="hidden md:flex items-center space-x-8">
            <button 
              onClick={() => setCurrentPage('home')}
              className={`hover:text-rose-500 transition-colors font-medium ${currentPage === 'home' ? 'text-rose-500' : 'text-gray-700'}`}
            >
              Home
            </button>
            <button 
              onClick={() => setCurrentPage('packages')}
              className={`hover:text-rose-500 transition-colors font-medium ${currentPage === 'packages' ? 'text-rose-500' : 'text-gray-700'}`}
            >
              Packages
            </button>
            <button 
              onClick={() => setCurrentPage('contact')}
              className={`hover:text-rose-500 transition-colors font-medium ${currentPage === 'contact' ? 'text-rose-500' : 'text-gray-700'}`}
            >
              Contact
            </button>
            <button 
              onClick={() => setCurrentPage('terms')}
              className={`hover:text-rose-500 transition-colors font-medium ${currentPage === 'terms' ? 'text-rose-500' : 'text-gray-700'}`}
            >
              Terms
            </button>
            {user ? (
              <div className="flex items-center space-x-4">
                <button 
                  onClick={() => setCurrentPage('profile')}
                  className="flex items-center space-x-2 text-gray-600 hover:text-rose-500 transition-colors"
                >
                  <User size={18} />
                  <span>Hi, {user.name.split(' ')[0]}</span>
                </button>
                <button 
                  onClick={() => setUser(null)}
                  className="text-rose-500 hover:text-rose-600 transition-colors font-medium"
                >
                  Logout
                </button>
              </div>
            ) : (
              <button 
                onClick={() => setShowLoginForm(true)}
                className="bg-gradient-to-r from-rose-500 to-purple-600 text-white px-6 py-2 rounded-full hover:shadow-lg transform hover:scale-105 transition-all font-medium"
              >
                Login
              </button>
            )}
          </div>

          <button 
            className="md:hidden p-2 hover:bg-rose-50 rounded-lg transition-colors"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {isMenuOpen && (
          <div className="md:hidden mt-4 pb-4 border-t border-rose-100 pt-4 bg-white/95 backdrop-blur-md">
            <div className="flex flex-col space-y-4">
              <button 
                onClick={() => { setCurrentPage('home'); setIsMenuOpen(false); }}
                className="text-left hover:text-rose-500 transition-colors font-medium py-2"
              >
                Home
              </button>
              <button 
                onClick={() => { setCurrentPage('packages'); setIsMenuOpen(false); }}
                className="text-left hover:text-rose-500 transition-colors font-medium py-2"
              >
                Packages
              </button>
              <button 
                onClick={() => { setCurrentPage('contact'); setIsMenuOpen(false); }}
                className="text-left hover:text-rose-500 transition-colors font-medium py-2"
              >
                Contact
              </button>
              <button 
                onClick={() => { setCurrentPage('terms'); setIsMenuOpen(false); }}
                className="text-left hover:text-rose-500 transition-colors font-medium py-2"
              >
                Terms
              </button>
              {user ? (
                <div className="flex flex-col space-y-3 pt-2 border-t border-rose-100">
                  <button 
                    onClick={() => { setCurrentPage('profile'); setIsMenuOpen(false); }}
                    className="text-left text-gray-600 hover:text-rose-500 transition-colors py-2"
                  >
                    Hi, {user.name}
                  </button>
                  <button 
                    onClick={() => { setUser(null); setIsMenuOpen(false); }}
                    className="text-left text-rose-500 hover:text-rose-600 transition-colors font-medium py-2"
                  >
                    Logout
                  </button>
                </div>
              ) : (
                <button 
                  onClick={() => { setShowLoginForm(true); setIsMenuOpen(false); }}
                  className="bg-gradient-to-r from-rose-500 to-purple-600 text-white px-6 py-3 rounded-full text-center font-medium mt-2"
                >
                  Login
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    </nav>
  );

  const HomePage = () => (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-rose-100 via-purple-50 to-pink-100"></div>
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-20 left-10 w-32 h-32 bg-rose-300 rounded-full animate-pulse"></div>
          <div className="absolute top-40 right-20 w-24 h-24 bg-purple-300 rounded-full animate-bounce"></div>
          <div className="absolute bottom-32 left-20 w-16 h-16 bg-pink-300 rounded-full animate-ping"></div>
          <div className="absolute top-60 left-1/2 w-20 h-20 bg-rose-200 rounded-full animate-pulse"></div>
        </div>
        
        <div className="relative z-10 text-center px-4 max-w-5xl mx-auto">
          <div className="mb-8 animate-on-scroll">
            <Heart className="text-rose-500 fill-current mx-auto mb-4 animate-pulse" size={60} />
          </div>
          <h1 className="text-6xl md:text-8xl font-bold mb-6 bg-gradient-to-r from-rose-500 via-purple-600 to-pink-500 bg-clip-text text-transparent animate-on-scroll">
            WildlyTogether
          </h1>
          <p className="text-2xl md:text-3xl text-gray-700 mb-6 animate-on-scroll font-light">
            Creating magical moments for your special occasions
          </p>
          <p className="text-lg md:text-xl text-gray-600 mb-12 animate-on-scroll max-w-3xl mx-auto leading-relaxed">
            From romantic dates to unforgettable proposals, we craft experiences that last a lifetime. 
            Every detail is designed to make your heart skip a beat.
          </p>
          <div className="flex flex-col sm:flex-row gap-6 justify-center animate-on-scroll">
            <button 
              onClick={() => setCurrentPage('packages')}
              className="bg-gradient-to-r from-rose-500 to-purple-600 text-white px-10 py-4 rounded-full text-lg font-semibold hover:shadow-2xl transform hover:scale-105 transition-all duration-300 flex items-center justify-center space-x-2"
            >
              <Heart size={20} />
              <span>Book Your Surprise</span>
            </button>
            <a 
              href="https://wa.me/1234567890?text=Hi%20I%20want%20to%20know%20more%20about%20your%20magical%20services!"
              className="border-2 border-rose-500 text-rose-500 px-10 py-4 rounded-full text-lg font-semibold hover:bg-rose-500 hover:text-white transition-all duration-300 flex items-center justify-center space-x-2 hover:shadow-lg"
            >
              <MessageCircle size={20} />
              <span>Chat on WhatsApp</span>
            </a>
          </div>
        </div>
      </section>

      {/* Featured Packages */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-20 animate-on-scroll">
            <h2 className="text-5xl font-bold text-gray-800 mb-6">Featured Packages</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Handcrafted experiences for your special moments, each designed to create unforgettable memories
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
            {packages.slice(0, 3).map((pkg, index) => (
              <div 
                key={pkg.id}
                className="bg-white rounded-3xl shadow-xl overflow-hidden hover:shadow-2xl transform hover:scale-105 transition-all duration-500 animate-on-scroll group"
                style={{ animationDelay: `${index * 0.2}s` }}
              >
                <div className="relative h-64 overflow-hidden">
                  <img 
                    src={pkg.image} 
                    alt={pkg.name}
                    className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
                  <div className="absolute top-4 right-4 bg-rose-500 text-white px-4 py-2 rounded-full text-sm font-semibold shadow-lg">
                    Save ₹{pkg.originalPrice - pkg.price}
                  </div>
                </div>
                <div className="p-8">
                  <h3 className="text-2xl font-bold text-gray-800 mb-3">{pkg.name}</h3>
                  <p className="text-gray-600 mb-6 line-clamp-3">{pkg.description}</p>
                  <div className="flex items-center space-x-3 mb-6">
                    <span className="text-3xl font-bold text-rose-500">₹{pkg.price.toLocaleString()}</span>
                    <span className="text-lg text-gray-400 line-through">₹{pkg.originalPrice.toLocaleString()}</span>
                  </div>
                  <button 
                    onClick={() => { setSelectedPackage(pkg); setCurrentPage('package-detail'); }}
                    className="w-full bg-gradient-to-r from-rose-500 to-purple-600 text-white py-4 rounded-xl hover:shadow-lg transform hover:scale-105 transition-all font-semibold text-lg"
                  >
                    View Details
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mt-16 animate-on-scroll">
            <button 
              onClick={() => setCurrentPage('packages')}
              className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-8 py-3 rounded-full hover:shadow-lg transform hover:scale-105 transition-all font-semibold"
            >
              View All Packages
            </button>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-24 bg-gradient-to-br from-rose-50 via-purple-50 to-pink-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-20 animate-on-scroll">
            <h2 className="text-5xl font-bold text-gray-800 mb-6">Why Choose WildlyTogether?</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              We make your dreams come true with attention to every detail, creating moments that will be cherished forever
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-12 max-w-6xl mx-auto">
            {[
              {
                icon: <Heart className="text-rose-500" size={48} />,
                title: "Personalized Touch",
                description: "Every setup is customized to your unique love story and preferences. We listen to your dreams and bring them to life with magical attention to detail."
              },
              {
                icon: <Star className="text-purple-500" size={48} />,
                title: "Quality Guaranteed",
                description: "We use only the finest materials and decorations for your special moments. Premium quality meets artistic vision in every setup we create."
              },
              {
                icon: <Calendar className="text-pink-500" size={48} />,
                title: "Perfect Timing",
                description: "Professional setup and coordination to ensure everything is perfect when you arrive. Seamless execution that lets you focus on what matters most."
              }
            ].map((feature, index) => (
              <div 
                key={index}
                className="text-center p-10 bg-white rounded-3xl shadow-xl hover:shadow-2xl transition-all duration-500 animate-on-scroll group"
                style={{ animationDelay: `${index * 0.2}s` }}
              >
                <div className="inline-block p-6 bg-gradient-to-br from-rose-100 to-purple-100 rounded-full mb-8 group-hover:scale-110 transition-transform">
                  {feature.icon}
                </div>
                <h3 className="text-2xl font-bold text-gray-800 mb-6">{feature.title}</h3>
                <p className="text-gray-600 leading-relaxed">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-gradient-to-r from-rose-500 via-purple-600 to-pink-500">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-4xl mx-auto animate-on-scroll">
            <h2 className="text-5xl font-bold text-white mb-6">Ready to Create Magic?</h2>
            <p className="text-xl text-white/90 mb-12 leading-relaxed">
              Let us transform your special moments into unforgettable memories. 
              Every love story deserves a magical chapter.
            </p>
            <div className="flex flex-col sm:flex-row gap-6 justify-center">
              <button 
                onClick={() => setCurrentPage('packages')}
                className="bg-white text-rose-500 px-10 py-4 rounded-full text-lg font-semibold hover:shadow-2xl transform hover:scale-105 transition-all duration-300"
              >
                Explore Packages
              </button>
              <a 
                href="https://wa.me/1234567890?text=Hi%20I%20want%20to%20create%20something%20magical!"
                className="border-2 border-white text-white px-10 py-4 rounded-full text-lg font-semibold hover:bg-white hover:text-rose-500 transition-all duration-300"
              >
                Start Planning
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );

  const PackagesPage = () => (
    <div className="min-h-screen pt-20 bg-gradient-to-br from-rose-50 to-purple-50">
      <div className="container mx-auto px-4 py-16">
        <div className="text-center mb-16 animate-on-scroll">
          <h1 className="text-5xl font-bold text-gray-800 mb-6">Our Magical Packages</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Choose the perfect setup for your special occasion. Each package is crafted with love and attention to detail.
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-4 mb-16 animate-on-scroll">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              className={`flex items-center space-x-2 px-6 py-3 rounded-full font-semibold transition-all duration-300 ${
                selectedCategory === category.id
                  ? 'bg-gradient-to-r from-rose-500 to-purple-600 text-white shadow-lg'
                  : 'bg-white text-gray-600 hover:bg-rose-50 hover:text-rose-500 shadow-md'
              }`}
            >
              {category.icon}
              <span>{category.name}</span>
            </button>
          ))}
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-10 max-w-7xl mx-auto">
          {filteredPackages.map((pkg, index) => (
            <div 
              key={pkg.id}
              className="bg-white rounded-3xl shadow-xl overflow-hidden hover:shadow-2xl transform hover:scale-105 transition-all duration-500 animate-on-scroll group"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="relative h-72 overflow-hidden">
                <img 
                  src={pkg.image} 
                  alt={pkg.name}
                  className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent"></div>
                <div className="absolute top-4 right-4 bg-rose-500 text-white px-4 py-2 rounded-full text-sm font-semibold shadow-lg">
                  Save ₹{pkg.originalPrice - pkg.price}
                </div>
              </div>
              <div className="p-8">
                <h3 className="text-2xl font-bold text-gray-800 mb-3">{pkg.name}</h3>
                <p className="text-gray-600 mb-6 line-clamp-3">{pkg.description}</p>
                <div className="mb-6">
                  {pkg.features.slice(0, 3).map((feature, idx) => (
                    <div key={idx} className="flex items-center space-x-2 mb-2">
                      <Star className="text-rose-400 fill-current" size={14} />
                      <span className="text-sm text-gray-600">{feature}</span>
                    </div>
                  ))}
                  {pkg.features.length > 3 && (
                    <span className="text-sm text-rose-500 font-medium">+{pkg.features.length - 3} more features</span>
                  )}
                </div>
                <div className="flex items-center space-x-3 mb-6">
                  <span className="text-3xl font-bold text-rose-500">₹{pkg.price.toLocaleString()}</span>
                  <span className="text-lg text-gray-400 line-through">₹{pkg.originalPrice.toLocaleString()}</span>
                </div>
                <div className="flex space-x-3">
                  <button 
                    onClick={() => { setSelectedPackage(pkg); setCurrentPage('package-detail'); }}
                    className="flex-1 bg-gradient-to-r from-rose-500 to-purple-600 text-white py-3 rounded-xl hover:shadow-lg transform hover:scale-105 transition-all font-semibold"
                  >
                    View Details
                  </button>
                  <a 
                    href={`https://wa.me/1234567890?text=Hi%20I%20want%20to%20book%20the%20${pkg.name}!%20Price:%20₹${pkg.price}`}
                    className="bg-green-500 text-white p-3 rounded-xl hover:bg-green-600 transition-colors shadow-lg hover:shadow-xl"
                  >
                    <MessageCircle size={20} />
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const PackageDetailPage = () => {
    if (!selectedPackage) return null;

    return (
      <div className="min-h-screen pt-20 bg-white">
        <div className="container mx-auto px-4 py-16">
          <button 
            onClick={() => setCurrentPage('packages')}
            className="flex items-center space-x-2 text-rose-500 hover:text-rose-600 transition-colors mb-8 font-medium"
          >
            <ArrowLeft size={20} />
            <span>Back to Packages</span>
          </button>

          <div className="max-w-7xl mx-auto">
            <div className="grid lg:grid-cols-2 gap-16 mb-16">
              <div className="animate-on-scroll">
                <div className="relative h-96 lg:h-[500px] rounded-3xl overflow-hidden shadow-2xl">
                  <img 
                    src={selectedPackage.image} 
                    alt={selectedPackage.name}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
                </div>
              </div>
              
              <div className="animate-on-scroll">
                <h1 className="text-5xl font-bold text-gray-800 mb-6">{selectedPackage.name}</h1>
                <p className="text-xl text-gray-600 mb-8 leading-relaxed">{selectedPackage.description}</p>
                
                <div className="mb-8">
                  <h3 className="text-2xl font-semibold text-gray-800 mb-6">Package Includes:</h3>
                  <div className="grid sm:grid-cols-2 gap-3">
                    {selectedPackage.features.map((feature, idx) => (
                      <div key={idx} className="flex items-center space-x-3 p-3 bg-rose-50 rounded-xl">
                        <Star className="text-rose-500 fill-current" size={18} />
                        <span className="text-gray-700 font-medium">{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex items-center space-x-4 mb-10">
                  <span className="text-4xl font-bold text-rose-500">₹{selectedPackage.price.toLocaleString()}</span>
                  <span className="text-2xl text-gray-400 line-through">₹{selectedPackage.originalPrice.toLocaleString()}</span>
                  <span className="bg-rose-100 text-rose-600 px-4 py-2 rounded-full text-lg font-semibold">
                    Save ₹{(selectedPackage.originalPrice - selectedPackage.price).toLocaleString()}
                  </span>
                </div>

                <div className="flex flex-col sm:flex-row gap-4">
                  <button 
                    onClick={() => {
                      setBookingForm({ ...bookingForm, packageId: selectedPackage.id });
                      setCurrentPage('booking');
                    }}
                    className="flex-1 bg-gradient-to-r from-rose-500 to-purple-600 text-white py-4 px-8 rounded-xl text-lg font-semibold hover:shadow-xl transform hover:scale-105 transition-all duration-300 flex items-center justify-center space-x-2"
                  >
                    <Calendar size={20} />
                    <span>Book Now</span>
                  </button>
                  <a 
                    href={`https://wa.me/1234567890?text=Hi%20I%20want%20to%20book%20the%20${selectedPackage.name}!%20Price:%20₹${selectedPackage.price}%0A%0APlease%20share%20more%20details%20about%20this%20package.`}
                    className="bg-green-500 text-white py-4 px-8 rounded-xl text-lg font-semibold hover:bg-green-600 transition-colors flex items-center justify-center space-x-2 shadow-lg hover:shadow-xl"
                  >
                    <MessageCircle size={20} />
                    <span>WhatsApp</span>
                  </a>
                </div>
              </div>
            </div>

            {/* Additional Info */}
            <div className="grid md:grid-cols-3 gap-8 animate-on-scroll">
              <div className="bg-gradient-to-br from-rose-50 to-purple-50 p-8 rounded-3xl">
                <Clock className="text-rose-500 mb-4" size={32} />
                <h3 className="text-xl font-bold text-gray-800 mb-3">Setup Time</h3>
                <p className="text-gray-600">Professional setup takes 2-3 hours. We handle everything so you can focus on the moment.</p>
              </div>
              <div className="bg-gradient-to-br from-purple-50 to-pink-50 p-8 rounded-3xl">
                <CreditCard className="text-purple-500 mb-4" size={32} />
                <h3 className="text-xl font-bold text-gray-800 mb-3">Payment</h3>
                <p className="text-gray-600">50% advance required to confirm booking. Remaining amount on the day of event.</p>
              </div>
              <div className="bg-gradient-to-br from-pink-50 to-rose-50 p-8 rounded-3xl">
                <CheckCircle className="text-pink-500 mb-4" size={32} />
                <h3 className="text-xl font-bold text-gray-800 mb-3">Guarantee</h3>
                <p className="text-gray-600">100% satisfaction guaranteed. We ensure every detail is perfect for your special moment.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const BookingPage = () => (
    <div className="min-h-screen pt-20 bg-gradient-to-br from-rose-50 to-purple-50">
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12 animate-on-scroll">
            <h1 className="text-4xl font-bold text-gray-800 mb-4">Book Your Magical Experience</h1>
            <p className="text-xl text-gray-600">Fill in the details and we'll create something unforgettable for you</p>
          </div>

          {!user ? (
            <div className="bg-white rounded-3xl shadow-xl p-8 text-center animate-on-scroll">
              <Lock className="text-rose-500 mx-auto mb-4" size={48} />
              <h2 className="text-2xl font-bold text-gray-800 mb-4">Login Required</h2>
              <p className="text-gray-600 mb-6">Please login to continue with your booking</p>
              <button 
                onClick={() => setShowLoginForm(true)}
                className="bg-gradient-to-r from-rose-500 to-purple-600 text-white px-8 py-3 rounded-full font-semibold hover:shadow-lg transform hover:scale-105 transition-all"
              >
                Login to Continue
              </button>
            </div>
          ) : (
            <form onSubmit={handleBooking} className="bg-white rounded-3xl shadow-xl p-8 animate-on-scroll">
              <div className="grid md:grid-cols-2 gap-8">
                <div>
                  <label className="block text-gray-700 font-semibold mb-2">Package</label>
                  <div className="p-4 bg-rose-50 rounded-xl border border-rose-200">
                    <h3 className="font-bold text-gray-800">{selectedPackage?.name}</h3>
                    <p className="text-rose-500 font-semibold">₹{selectedPackage?.price.toLocaleString()}</p>
                  </div>
                </div>

                <div>
                  <label className="block text-gray-700 font-semibold mb-2">Event Date</label>
                  <input
                    type="date"
                    value={bookingForm.date}
                    onChange={(e) => setBookingForm({ ...bookingForm, date: e.target.value })}
                    className="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-rose-500 focus:border-transparent"
                    required
                  />
                </div>

                <div>
                  <label className="block text-gray-700 font-semibold mb-2">Preferred Time</label>
                  <select
                    value={bookingForm.time}
                    onChange={(e) => setBookingForm({ ...bookingForm, time: e.target.value })}
                    className="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-rose-500 focus:border-transparent"
                    required
                  >
                    <option value="">Select Time</option>
                    <option value="morning">Morning (8 AM - 12 PM)</option>
                    <option value="afternoon">Afternoon (12 PM - 4 PM)</option>
                    <option value="evening">Evening (4 PM - 8 PM)</option>
                    <option value="night">Night (8 PM - 12 AM)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-gray-700 font-semibold mb-2">Number of Guests</label>
                  <input
                    type="number"
                    min="1"
                    max="50"
                    value={bookingForm.guestCount}
                    onChange={(e) => setBookingForm({ ...bookingForm, guestCount: parseInt(e.target.value) })}
                    className="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-rose-500 focus:border-transparent"
                    required
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="block text-gray-700 font-semibold mb-2">Venue/Location</label>
                  <input
                    type="text"
                    value={bookingForm.venue}
                    onChange={(e) => setBookingForm({ ...bookingForm, venue: e.target.value })}
                    placeholder="Enter venue address or location details"
                    className="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-rose-500 focus:border-transparent"
                    required
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="block text-gray-700 font-semibold mb-2">Special Requests</label>
                  <textarea
                    value={bookingForm.specialRequests}
                    onChange={(e) => setBookingForm({ ...bookingForm, specialRequests: e.target.value })}
                    placeholder="Any special requests, themes, or customizations you'd like..."
                    rows="4"
                    className="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-rose-500 focus:border-transparent"
                  ></textarea>
                </div>
              </div>

              <div className="mt-8 p-6 bg-gradient-to-r from-rose-50 to-purple-50 rounded-xl">
                <h3 className="text-lg font-bold text-gray-800 mb-4">Payment Information</h3>
                <div className="grid sm:grid-cols-2 gap-4 text-sm text-gray-600">
                  <div>
                    <p><strong>Advance Payment (50%):</strong> ₹{selectedPackage ? (selectedPackage.price * 0.5).toLocaleString() : 0}</p>
                    <p><strong>Remaining Amount:</strong> ₹{selectedPackage ? (selectedPackage.price * 0.5).toLocaleString() : 0}</p>
                  </div>
                  <div>
                    <p><strong>Total Package Cost:</strong> ₹{selectedPackage?.price.toLocaleString()}</p>
                    <p className="text-rose-500 font-semibold">Payment on event day</p>
                  </div>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-4 mt-8">
                <button
                  type="submit"
                  className="flex-1 bg-gradient-to-r from-rose-500 to-purple-600 text-white py-4 px-8 rounded-xl text-lg font-semibold hover:shadow-xl transform hover:scale-105 transition-all duration-300"
                >
                  Submit Booking Request
                </button>
                <a 
                  href={`https://wa.me/1234567890?text=Hi%20I%20want%20to%20book%20${selectedPackage?.name}%20for%20${bookingForm.date}%20at%20${bookingForm.venue}`}
                  className="bg-green-500 text-white py-4 px-8 rounded-xl text-lg font-semibold hover:bg-green-600 transition-colors flex items-center justify-center space-x-2"
                >
                  <MessageCircle size={20} />
                  <span>Discuss on WhatsApp</span>
                </a>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );

  const ContactPage = () => (
    <div className="min-h-screen pt-20 bg-gradient-to-br from-rose-50 to-purple-50">
      <div className="container mx-auto px-4 py-16">
        <div className="text-center mb-16 animate-on-scroll">
          <h1 className="text-5xl font-bold text-gray-800 mb-6">Get in Touch</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Ready to create something magical? We'd love to hear about your special occasion and help bring your dreams to life.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-16 max-w-6xl mx-auto">
          {/* Contact Form */}
          <div className="animate-on-scroll">
            <form onSubmit={handleContactSubmit} className="bg-white rounded-3xl shadow-xl p-8">
              <h2 className="text-2xl font-bold text-gray-800 mb-6">Send us a Message</h2>
              
              <div className="space-y-6">
                <div>
                  <label className="block text-gray-700 font-semibold mb-2">Your Name</label>
                  <input
                    type="text"
                    value={contactForm.name}
                    onChange={(e) => setContactForm({ ...contactForm, name: e.target.value })}
                    className="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-rose-500 focus:border-transparent"
                    required
                  />
                </div>

                <div>
                  <label className="block text-gray-700 font-semibold mb-2">Email Address</label>
                  <input
                    type="email"
                    value={contactForm.email}
                    onChange={(e) => setContactForm({ ...contactForm, email: e.target.value })}
                    className="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-rose-500 focus:border-transparent"
                    required
                  />
                </div>

                <div>
                  <label className="block text-gray-700 font-semibold mb-2">Phone Number</label>
                  <input
                    type="tel"
                    value={contactForm.phone}
                    onChange={(e) => setContactForm({ ...contactForm, phone: e.target.value })}
                    className="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-rose-500 focus:border-transparent"
                    required
                  />
                </div>

                <div>
                  <label className="block text-gray-700 font-semibold mb-2">Your Message</label>
                  <textarea
                    value={contactForm.message}
                    onChange={(e) => setContactForm({ ...contactForm, message: e.target.value })}
                    placeholder="Tell us about your special occasion, preferred date, and any specific requirements..."
                    rows="6"
                    className="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-rose-500 focus:border-transparent"
                    required
                  ></textarea>
                </div>

                <button
                  type="submit"
                  className="w-full bg-gradient-to-r from-rose-500 to-purple-600 text-white py-4 px-8 rounded-xl text-lg font-semibold hover:shadow-xl transform hover:scale-105 transition-all duration-300 flex items-center justify-center space-x-2"
                >
                  <Send size={20} />
                  <span>Send Message</span>
                </button>
              </div>
            </form>
          </div>

          {/* Contact Info */}
          <div className="animate-on-scroll">
            <div className="bg-white rounded-3xl shadow-xl p-8 h-full">
              <h2 className="text-2xl font-bold text-gray-800 mb-8">Let's Connect</h2>
              
              <div className="space-y-8">
                <div className="flex items-start space-x-4">
                  <div className="bg-rose-100 p-3 rounded-full">
                    <MessageCircle className="text-rose-500" size={24} />
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-800 mb-2">WhatsApp</h3>
                    <p className="text-gray-600 mb-3">Get instant responses and quick planning assistance</p>
                    <a 
                      href="https://wa.me/1234567890?text=Hi%20I%20want%20to%20know%20more%20about%20your%20services!"
                      className="bg-green-500 text-white px-6 py-2 rounded-full hover:bg-green-600 transition-colors inline-flex items-center space-x-2"
                    >
                      <MessageCircle size={16} />
                      <span>Chat Now</span>
                    </a>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="bg-purple-100 p-3 rounded-full">
                    <Phone className="text-purple-500" size={24} />
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-800 mb-2">Phone</h3>
                    <p className="text-gray-600 mb-2">Call us for detailed discussions</p>
                    <a href="tel:+911234567890" className="text-purple-500 font-semibold hover:text-purple-600 transition-colors">
                      +91 12345 67890
                    </a>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="bg-pink-100 p-3 rounded-full">
                    <Mail className="text-pink-500" size={24} />
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-800 mb-2">Email</h3>
                    <p className="text-gray-600 mb-2">Send us detailed requirements</p>
                    <a href="mailto:hello@wildlytogether.com" className="text-pink-500 font-semibold hover:text-pink-600 transition-colors">
                      hello@wildlytogether.com
                    </a>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="bg-rose-100 p-3 rounded-full">
                    <MapPin className="text-rose-500" size={24} />
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-800 mb-2">Service Areas</h3>
                    <p className="text-gray-600">We serve across the city and surrounding areas. Contact us to confirm availability in your location.</p>
                  </div>
                </div>
              </div>

              <div className="mt-8 p-6 bg-gradient-to-r from-rose-50 to-purple-50 rounded-xl">
                <h3 className="font-bold text-gray-800 mb-3">Quick Response Promise</h3>
                <p className="text-gray-600 text-sm">
                  We typically respond to all inquiries within 2-4 hours during business hours. 
                  For urgent requests, WhatsApp is the fastest way to reach us!
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const TermsPage = () => (
    <div className="min-h-screen pt-20 bg-white">
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16 animate-on-scroll">
            <h1 className="text-5xl font-bold text-gray-800 mb-6">Terms & Conditions</h1>
            <p className="text-xl text-gray-600">
              Thank you for choosing WildlyTogether! We're excited to plan something magical for you. 
              Please review our terms and conditions before confirming your booking.
            </p>
          </div>

          <div className="bg-white rounded-3xl shadow-xl p-8 animate-on-scroll">
            <div className="space-y-12">
              {/* Booking & Payments */}
              <section>
                <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center space-x-3">
                  <CreditCard className="text-rose-500" size={28} />
                  <span>1. Booking & Payments</span>
                </h2>
                <div className="space-y-4 text-gray-600 leading-relaxed">
                  <p>• A minimum <strong className="text-gray-800">50% advance payment</strong> is required to confirm your booking.</p>
                  <p>• The remaining amount must be settled on the day of the event, before the setup begins.</p>
                  <p>• All payments are <strong className="text-gray-800">non-refundable</strong> once the setup process begins.</p>
                </div>
              </section>

              {/* Cancellation & Refund */}
              <section>
                <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center space-x-3">
                  <Clock className="text-purple-500" size={28} />
                  <span>2. Cancellation & Refund Policy</span>
                </h2>
                <div className="space-y-4 text-gray-600 leading-relaxed">
                  <p>• Cancellations made <strong className="text-gray-800">7 days before</strong> the event will receive a 50% refund of the advance.</p>
                  <p>• Cancellations made <strong className="text-gray-800">within 72 hours</strong> of the event are non-refundable due to planning and material costs.</p>
                  <p>• In case of extreme weather or emergency, we will offer a <strong className="text-gray-800">reschedule (1 time only)</strong> based on availability.</p>
                </div>
              </section>

              {/* Customization */}
              <section>
                <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center space-x-3">
                  <Star className="text-pink-500" size={28} />
                  <span>3. Customization</span>
                </h2>
                <div className="space-y-4 text-gray-600 leading-relaxed">
                  <p>• We offer <strong className="text-gray-800">full customization</strong> based on your theme, color preference, and occasion.</p>
                  <p>• Final design details must be confirmed at least <strong className="text-gray-800">3 days prior</strong> to the event.</p>
                  <p>• Last-minute changes may not be guaranteed or may incur additional charges.</p>
                </div>
              </section>

              {/* Setup & Venue */}
              <section>
                <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center space-x-3">
                  <MapPin className="text-rose-500" size={28} />
                  <span>4. Setup & Venue</span>
                </h2>
                <div className="space-y-4 text-gray-600 leading-relaxed">
                  <p>• Clients must ensure <strong className="text-gray-800">venue permissions</strong> (for parks, rooftops, private spaces).</p>
                  <p>• Setup duration ranges from <strong className="text-gray-800">1–3 hours</strong> depending on the package.</p>
                  <p>• We are not responsible for venue-specific restrictions (power supply, access, etc.).</p>
                </div>
              </section>

              {/* Damages & Responsibility */}
              <section>
                <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center space-x-3">
                  <CheckCircle className="text-purple-500" size={28} />
                  <span>5. Damages & Responsibility</span>
                </h2>
                <div className="space-y-4 text-gray-600 leading-relaxed">
                  <p>• Any intentional damage to décor items or property will be <strong className="text-gray-800">chargeable to the client</strong>.</p>
                  <p>• We are not liable for loss or damage to any personal belongings during the event.</p>
                </div>
              </section>

              {/* Photography & Promotion */}
              <section>
                <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center space-x-3">
                  <Eye className="text-pink-500" size={28} />
                  <span>6. Photography & Promotion</span>
                </h2>
                <div className="space-y-4 text-gray-600 leading-relaxed">
                  <p>• WildlyTogether reserves the right to use event photos/videos for <strong className="text-gray-800">marketing purposes</strong> unless otherwise requested in writing.</p>
                </div>
              </section>

              {/* Safety */}
              <section>
                <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center space-x-3">
                  <Heart className="text-rose-500" size={28} />
                  <span>7. Safety</span>
                </h2>
                <div className="space-y-4 text-gray-600 leading-relaxed">
                  <p>• Open flames (candles) are used with care; <strong className="text-gray-800">children should be supervised</strong> at all times.</p>
                  <p>• Weather-related risks will be communicated and alternatives will be discussed when possible.</p>
                </div>
              </section>
            </div>

            <div className="mt-12 p-8 bg-gradient-to-r from-rose-50 via-purple-50 to-pink-50 rounded-2xl text-center">
              <Heart className="text-rose-500 fill-current mx-auto mb-4" size={40} />
              <p className="text-lg text-gray-700 mb-4">
                <strong>By confirming your booking, you agree to these terms and conditions.</strong>
              </p>
              <p className="text-xl font-semibold bg-gradient-to-r from-rose-500 to-purple-600 bg-clip-text text-transparent">
                Let's create something unforgettable! 💫
              </p>
              <p className="text-rose-500 font-medium mt-2">#WildlyTogetherSurprisePlanner</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const ProfilePage = () => (
    <div className="min-h-screen pt-20 bg-gradient-to-br from-rose-50 to-purple-50">
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12 animate-on-scroll">
            <h1 className="text-4xl font-bold text-gray-800 mb-4">Welcome back, {user?.name}!</h1>
            <p className="text-xl text-gray-600">Manage your bookings and account details</p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* User Info */}
            <div className="lg:col-span-1 animate-on-scroll">
              <div className="bg-white rounded-3xl shadow-xl p-8">
                <div className="text-center mb-8">
                  <div className="w-24 h-24 bg-gradient-to-r from-rose-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
                    <User className="text-white" size={40} />
                  </div>
                  <h2 className="text-2xl font-bold text-gray-800">{user?.name}</h2>
                  <p className="text-gray-600">{user?.email}</p>
                  <p className="text-gray-600">{user?.phone}</p>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-rose-50 rounded-xl">
                    <span className="text-gray-700">Total Bookings</span>
                    <span className="font-bold text-rose-500">{userBookings.length}</span>
                  </div>
                  <div className="flex items-center justify-between p-4 bg-purple-50 rounded-xl">
                    <span className="text-gray-700">Member Since</span>
                    <span className="font-bold text-purple-500">2024</span>
                  </div>
                </div>

                <button className="w-full mt-6 bg-gradient-to-r from-rose-500 to-purple-600 text-white py-3 rounded-xl hover:shadow-lg transform hover:scale-105 transition-all">
                  Edit Profile
                </button>
              </div>
            </div>

            {/* Bookings */}
            <div className="lg:col-span-2 animate-on-scroll">
              <div className="bg-white rounded-3xl shadow-xl p-8">
                <h2 className="text-2xl font-bold text-gray-800 mb-8">Your Bookings</h2>
                
                {userBookings.length === 0 ? (
                  <div className="text-center py-12">
                    <Calendar className="text-gray-400 mx-auto mb-4" size={48} />
                    <p className="text-gray-500 text-lg">No bookings yet</p>
                    <button 
                      onClick={() => setCurrentPage('packages')}
                      className="mt-4 bg-gradient-to-r from-rose-500 to-purple-600 text-white px-6 py-3 rounded-full hover:shadow-lg transform hover:scale-105 transition-all"
                    >
                      Browse Packages
                    </button>
                  </div>
                ) : (
                  <div className="space-y-6">
                    {userBookings.map((booking) => (
                      <div key={booking.id} className="border border-gray-200 rounded-2xl p-6 hover:shadow-lg transition-shadow">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-4">
                          <h3 className="text-xl font-bold text-gray-800">{booking.packageName}</h3>
                          <span className={`px-4 py-2 rounded-full text-sm font-semibold ${
                            booking.status === 'confirmed' 
                              ? 'bg-green-100 text-green-600' 
                              : booking.status === 'pending'
                              ? 'bg-yellow-100 text-yellow-600'
                              : 'bg-gray-100 text-gray-600'
                          }`}>
                            {booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
                          </span>
                        </div>
                        <div className="grid sm:grid-cols-3 gap-4 text-sm text-gray-600">
                          <div>
                            <strong>Date:</strong> {new Date(booking.date).toLocaleDateString()}
                          </div>
                          <div>
                            <strong>Venue:</strong> {booking.venue}
                          </div>
                          <div>
                            <strong>Amount:</strong> ₹{booking.amount.toLocaleString()}
                          </div>
                        </div>
                        <div className="flex space-x-3 mt-4">
                          <a 
                            href={`https://wa.me/1234567890?text=Hi%20I%20want%20to%20discuss%20my%20booking%20for%20${booking.packageName}%20on%20${booking.date}`}
                            className="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 transition-colors flex items-center space-x-2"
                          >
                            <MessageCircle size={16} />
                            <span>Contact</span>
                          </a>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const LoginModal = () => (
    showLoginForm && (
      <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-3xl shadow-2xl p-8 w-full max-w-md animate-on-scroll">
          <div className="text-center mb-8">
            <Heart className="text-rose-500 fill-current mx-auto mb-4" size={40} />
            <h2 className="text-2xl font-bold text-gray-800">
              {isSignup ? 'Create Account' : 'Welcome Back'}
            </h2>
            <p className="text-gray-600">
              {isSignup ? 'Join us to book magical experiences' : 'Login to continue your journey'}
            </p>
          </div>

          <form onSubmit={handleLogin} className="space-y-6">
            {isSignup && (
              <div>
                <label className="block text-gray-700 font-semibold mb-2">Full Name</label>
                <input
                  type="text"
                  value={loginForm.name}
                  onChange={(e) => setLoginForm({ ...loginForm, name: e.target.value })}
                  className="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-rose-500 focus:border-transparent"
                  required={isSignup}
                />
              </div>
            )}

            <div>
              <label className="block text-gray-700 font-semibold mb-2">Email Address</label>
              <input
                type="email"
                value={loginForm.email}
                onChange={(e) => setLoginForm({ ...loginForm, email: e.target.value })}
                className="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-rose-500 focus:border-transparent"
                required
              />
            </div>

            {isSignup && (
              <div>
                <label className="block text-gray-700 font-semibold mb-2">Phone Number</label>
                <input
                  type="tel"
                  value={loginForm.phone}
                  onChange={(e) => setLoginForm({ ...loginForm, phone: e.target.value })}
                  className="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-rose-500 focus:border-transparent"
                  required={isSignup}
                />
              </div>
            )}

            <div>
              <label className="block text-gray-700 font-semibold mb-2">Password</label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={loginForm.password}
                  onChange={(e) => setLoginForm({ ...loginForm, password: e.target.value })}
                  className="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-rose-500 focus:border-transparent pr-12"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-gradient-to-r from-rose-500 to-purple-600 text-white py-4 rounded-xl text-lg font-semibold hover:shadow-xl transform hover:scale-105 transition-all duration-300"
            >
              {isSignup ? 'Create Account' : 'Login'}
            </button>
          </form>

          <div className="text-center mt-6">
            <button
              onClick={() => setIsSignup(!isSignup)}
              className="text-rose-500 hover:text-rose-600 transition-colors font-medium"
            >
              {isSignup ? 'Already have an account? Login' : "Don't have an account? Sign up"}
            </button>
          </div>

          <button
            onClick={() => setShowLoginForm(false)}
            className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X size={24} />
          </button>
        </div>
      </div>
    )
  );

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage />;
      case 'packages':
        return <PackagesPage />;
      case 'package-detail':
        return <PackageDetailPage />;
      case 'booking':
        return <BookingPage />;
      case 'contact':
        return <ContactPage />;
      case 'terms':
        return <TermsPage />;
      case 'profile':
        return <ProfilePage />;
      default:
        return <HomePage />;
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      {renderPage()}
      <LoginModal />
      
      {/* WhatsApp Float Button */}
      <a
        href="https://wa.me/1234567890?text=Hi%20I%20want%20to%20know%20more%20about%20WildlyTogether%20services!"
        className="fixed bottom-6 right-6 bg-green-500 text-white p-4 rounded-full shadow-2xl hover:bg-green-600 transition-all duration-300 hover:scale-110 z-40"
      >
        <MessageCircle size={24} />
      </a>
    </div>
  );
}

export default App;